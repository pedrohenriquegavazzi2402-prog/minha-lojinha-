const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// ====== CONFIGURAÇÃO DE SENHA DO ADMIN ======
// Altere a senha abaixo antes de publicar!
// A senha padrão é: gavazzi2026
const ADMIN_PASSWORD_HASH = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'gavazzi2026', 10);
// ============================================

const PRODUCTS_FILE = path.join(__dirname, 'data', 'products.json');
const UPLOADS_DIR = path.join(__dirname, 'public', 'images', 'uploads');

// Ensure directories exist
if (!fs.existsSync(path.join(__dirname, 'data'))) fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'pipas-gavazzi-secret-change-me-in-production-2026',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Multer for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, unique + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    if (/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error('Apenas imagens são permitidas'));
  }
});

// Helpers
function readProducts() {
  try {
    const data = fs.readFileSync(PRODUCTS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
}

function writeProducts(products) {
  fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2), 'utf8');
}

function requireAuth(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: 'Não autorizado' });
}

// ====== PUBLIC API ======
app.get('/api/products', (req, res) => {
  const products = readProducts().filter(p => p.active !== false);
  res.json(products);
});

// ====== ADMIN AUTH ======
app.post('/api/admin/login', (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Senha obrigatória' });

  if (bcrypt.compareSync(password, ADMIN_PASSWORD_HASH)) {
    req.session.isAdmin = true;
    return res.json({ success: true });
  }
  return res.status(401).json({ error: 'Senha incorreta' });
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/admin/check', (req, res) => {
  res.json({ authenticated: !!(req.session && req.session.isAdmin) });
});

// ====== ADMIN PRODUCTS CRUD ======
app.get('/api/admin/products', requireAuth, (req, res) => {
  res.json(readProducts());
});

app.post('/api/admin/products', requireAuth, upload.single('image'), (req, res) => {
  const products = readProducts();
  const { name, description, price, stock, active } = req.body;

  if (!name || !price) {
    return res.status(400).json({ error: 'Nome e preço são obrigatórios' });
  }

  const id = 'prod_' + Date.now();
  const newProduct = {
    id,
    name: name.trim(),
    description: (description || '').trim(),
    price: parseFloat(price),
    stock: parseInt(stock) || 0,
    image: req.file ? `/images/uploads/${req.file.filename}` : '/images/kit10.jpg',
    imageFull: req.file ? `/images/uploads/${req.file.filename}` : '/images/kit10.jpg',
    active: active !== 'false' && active !== false
  };

  products.push(newProduct);
  writeProducts(products);
  res.json(newProduct);
});

app.put('/api/admin/products/:id', requireAuth, upload.single('image'), (req, res) => {
  const products = readProducts();
  const idx = products.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Produto não encontrado' });

  const { name, description, price, stock, active } = req.body;
  const product = products[idx];

  if (name) product.name = name.trim();
  if (description !== undefined) product.description = description.trim();
  if (price) product.price = parseFloat(price);
  if (stock !== undefined) product.stock = parseInt(stock);
  if (active !== undefined) product.active = active !== 'false' && active !== false;
  if (req.file) {
    product.image = `/images/uploads/${req.file.filename}`;
    product.imageFull = product.image;
  }

  writeProducts(products);
  res.json(product);
});

app.delete('/api/admin/products/:id', requireAuth, (req, res) => {
  let products = readProducts();
  const before = products.length;
  products = products.filter(p => p.id !== req.params.id);
  if (products.length === before) return res.status(404).json({ error: 'Produto não encontrado' });
  writeProducts(products);
  res.json({ success: true });
});

// Serve admin page
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Fallback to index
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🪁 PIPAS GAVAZZI rodando em http://localhost:${PORT}`);
  console.log(`   Admin: http://localhost:${PORT}/admin`);
  console.log(`   Senha padrão: gavazzi2026 (altere no server.js ou variável ADMIN_PASSWORD)\n`);
});
