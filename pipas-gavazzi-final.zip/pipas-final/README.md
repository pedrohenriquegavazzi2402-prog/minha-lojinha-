# PIPAS GAVAZZI - Loja Virtual Completa

## O que tem

- Loja pública com carrinho e WhatsApp
- Painel administrativo com **senha real no servidor**
- Produtos, preços e fotos editáveis pelo admin
- Chave PIX: pgavazzi424@gmail.com
- Login protegido (bcrypt + sessão)
- Logout seguro

## Senha do Admin

Padrão: `gavazzi2026`

**Altere antes de publicar!**  
Defina a variável de ambiente `ADMIN_PASSWORD` no Render com uma senha forte.

## Como publicar no Render.com (recomendado)

1. Crie conta em https://render.com
2. New → Web Service
3. Envie os arquivos (GitHub ou upload)
4. Configurações:
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
5. Variáveis de ambiente:
   - `ADMIN_PASSWORD` = sua senha forte
   - `SESSION_SECRET` = qualquer frase secreta longa
6. Crie o serviço

Depois acesse:
- Loja: `https://seu-site.onrender.com`
- Admin: `https://seu-site.onrender.com/admin`

## Rodar local

```bash
npm install
npm start
```

Acesse http://localhost:3000 e http://localhost:3000/admin
