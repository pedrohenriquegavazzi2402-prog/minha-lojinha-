// PIPAS GAVAZZI - Store App
const WHATSAPP_NUMBER = '5514991598743';

let products = [];
let cart = JSON.parse(localStorage.getItem('pipas_cart') || '[]');

// Load products from API or fallback
async function loadProducts() {
  try {
    const res = await fetch('/api/products');
    if (res.ok) {
      products = await res.json();
    } else {
      throw new Error('API offline');
    }
  } catch (e) {
    // Fallback products (for static testing)
    products = [
      {
        id: 'kit10',
        name: 'Kit com 10 Pipas',
        description: 'Kit com 10 pipas coloridas de bambu com rabiola. Ideal para revenda e diversão.',
        price: 44.90,
        stock: 50,
        image: '/images/kit10.jpg',
        active: true
      },
      {
        id: 'kit20',
        name: 'Kit com 20 Pipas',
        description: 'Kit com 20 pipas estampadas de personagens (Mario, Spider-Man, Naruto e mais). Perfeito para revenda.',
        price: 44.90,
        stock: 40,
        image: '/images/kit20.jpg',
        active: true
      },
      {
        id: 'nylon',
        name: 'Linha de Nylon para Pipa',
        description: 'Linha de nylon resistente para pipa (fio 0,35 - 0,40). Bobina de alta qualidade.',
        price: 19.90,
        stock: 100,
        image: '/images/nylon.jpg',
        active: true
      }
    ];
  }
  renderProducts();
  updateCartUI();
}

function formatPrice(value) {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function renderProducts() {
  const grid = document.getElementById('productsGrid');
  grid.innerHTML = products
    .filter(p => p.active)
    .map(p => `
      <article class="product-card" data-id="${p.id}">
        <img src="${p.image}" alt="${p.name}" class="product-image" loading="lazy"
             onerror="this.src='https://via.placeholder.com/400x400?text=Produto'">
        <div class="product-info">
          <h3 class="product-name">${p.name}</h3>
          <p class="product-desc">${p.description || ''}</p>
          <div class="product-price">${formatPrice(p.price)}</div>
          <div class="product-actions">
            <div class="qty-control">
              <button class="qty-btn" onclick="changeQty('${p.id}', -1)">−</button>
              <span class="qty-value" id="qty-${p.id}">1</span>
              <button class="qty-btn" onclick="changeQty('${p.id}', 1)">+</button>
            </div>
            <button class="btn-add" onclick="addToCart('${p.id}')" ${p.stock <= 0 ? 'disabled' : ''}>
              ${p.stock <= 0 ? 'Esgotado' : 'Adicionar'}
            </button>
          </div>
        </div>
      </article>
    `).join('');
}

function changeQty(id, delta) {
  const el = document.getElementById(`qty-${id}`);
  let val = parseInt(el.textContent) + delta;
  if (val < 1) val = 1;
  if (val > 99) val = 99;
  el.textContent = val;
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  if (!product || product.stock <= 0) return;

  const qtyEl = document.getElementById(`qty-${id}`);
  const qty = parseInt(qtyEl.textContent) || 1;

  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      qty: qty
    });
  }

  saveCart();
  updateCartUI();
  showToast(`${product.name} adicionado!`);
  // Reset qty
  qtyEl.textContent = '1';
}

function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  saveCart();
  updateCartUI();
}

function updateCartQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty < 1) {
    removeFromCart(id);
    return;
  }
  saveCart();
  updateCartUI();
}

function saveCart() {
  localStorage.setItem('pipas_cart', JSON.stringify(cart));
}

function getCartTotal() {
  return cart.reduce((sum, item) => sum + item.price * item.qty, 0);
}

function updateCartUI() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  document.getElementById('cartCount').textContent = count;

  const container = document.getElementById('cartItems');
  const totalEl = document.getElementById('cartTotal');
  const btn = document.getElementById('btnWhatsApp');

  if (cart.length === 0) {
    container.innerHTML = '<p class="empty-cart">Seu carrinho está vazio</p>';
    totalEl.textContent = formatPrice(0);
    btn.disabled = true;
    return;
  }

  container.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.image}" alt="${item.name}" class="cart-item-img">
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">${formatPrice(item.price)}</div>
        <div class="cart-item-actions">
          <div class="qty-control">
            <button class="qty-btn" onclick="updateCartQty('${item.id}', -1)">−</button>
            <span class="qty-value">${item.qty}</span>
            <button class="qty-btn" onclick="updateCartQty('${item.id}', 1)">+</button>
          </div>
          <button class="btn-remove" onclick="removeFromCart('${item.id}')">Remover</button>
        </div>
      </div>
    </div>
  `).join('');

  totalEl.textContent = formatPrice(getCartTotal());
  btn.disabled = false;
}

function openCart() {
  document.getElementById('cartSidebar').classList.add('open');
  document.getElementById('cartOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cartSidebar').classList.remove('open');
  document.getElementById('cartOverlay').classList.remove('open');
  document.body.style.overflow = '';
}

function buildWhatsAppMessage() {
  let msg = 'Olá! Gostaria de fazer o seguinte pedido na *PIPAS GAVAZZI*:\n\n';
  cart.forEach(item => {
    msg += `• ${item.name}\n  Qtd: ${item.qty} × ${formatPrice(item.price)} = *${formatPrice(item.price * item.qty)}*\n\n`;
  });
  msg += `*TOTAL DO PEDIDO: ${formatPrice(getCartTotal())}*\n\n`;
  msg += `💳 *Pagamento via PIX*\nChave PIX (e-mail): pgavazzi424@gmail.com\n\n`;
  msg += 'Aguardo confirmação e informações de entrega. Obrigado!';
  return msg;
}

function finalizeWhatsApp() {
  if (cart.length === 0) return;
  const message = buildWhatsAppMessage();
  const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

function showToast(text) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = text;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2200);
}

// Event listeners
document.getElementById('cartBtn').addEventListener('click', openCart);
document.getElementById('closeCart').addEventListener('click', closeCart);
document.getElementById('cartOverlay').addEventListener('click', closeCart);
document.getElementById('btnWhatsApp').addEventListener('click', finalizeWhatsApp);

// Init
loadProducts();
